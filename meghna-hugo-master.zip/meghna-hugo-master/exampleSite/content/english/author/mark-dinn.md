---
title: "Mark Dinn"
image: ""
email: "email2@example.org"
social:
  - icon : "ti-facebook" # themify icon pack : https://themify.me/themify-icons
    link : "#"
  - icon : "ti-twitter-alt" # themify icon pack : https://themify.me/themify-icons
    link : "#"
  - icon : "ti-github" # themify icon pack : https://themify.me/themify-icons
    link : "#"
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet vulputate augue. Duis auctor lacus id vehicula gravida. Nam suscipit vitae purus et laoreet.
Donec nisi dolor, consequat vel pretium id, auctor in dui. Nam iaculis, neque ac ullamcorper.